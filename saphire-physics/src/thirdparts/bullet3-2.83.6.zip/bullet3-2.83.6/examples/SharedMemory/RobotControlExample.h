#ifndef ROBOT_CONTROL_EXAMPLE_H
#define ROBOT_CONTROL_EXAMPLE_H

class CommonExampleInterface*    RobotControlExampleCreateFunc(struct CommonExampleOptions& options);

#endif //ROBOT_CONTROL_EXAMPLE_H


