#ifndef PHYSICS_SERVER_EXAMPLE_H
#define PHYSICS_SERVER_EXAMPLE_H


class CommonExampleInterface*    PhysicsServerCreateFunc(struct CommonExampleOptions& options);

#endif //PHYSICS_SERVER_EXAMPLE_H


