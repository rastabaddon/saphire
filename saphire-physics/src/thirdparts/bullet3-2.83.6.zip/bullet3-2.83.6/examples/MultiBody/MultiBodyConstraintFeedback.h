#ifndef MULTIBODY_CONSTRAINT_FEEDBACK_H
#define MULTIBODY_CONSTRAINT_FEEDBACK_H

class CommonExampleInterface*    MultiBodyConstraintFeedbackCreateFunc(struct CommonExampleOptions& options);

#endif //MULTIBODY_CONSTRAINT_FEEDBACK_H

