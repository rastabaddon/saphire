#ifndef TEST_JOINT_TORQUE_SETUP_H
#define TEST_JOINT_TORQUE_SETUP_H

class CommonExampleInterface*    TestJointTorqueCreateFunc(struct CommonExampleOptions& options);

#endif //TEST_JOINT_TORQUE_SETUP_H

